package co.com.validator.adapterreglas;

import co.com.validator.Legacy.ReglaRiesgoMontoInusual;
import co.com.validator.Regla;
import co.com.validator.Transaccion;

public class ReglaLegacyAdapter implements Regla {
    ReglaRiesgoMontoInusual reglaRiesgoMontoInusual;

    public ReglaLegacyAdapter(ReglaRiesgoMontoInusual reglaRiesgoMontoInusual){
        this.reglaRiesgoMontoInusual = reglaRiesgoMontoInusual;
    }
    @Override
    public String execute(Transaccion transaccion){
        return reglaRiesgoMontoInusual.aplicarRegla(transaccion);
    }
}

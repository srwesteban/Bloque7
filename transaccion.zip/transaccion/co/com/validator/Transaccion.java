package co.com.validator;

import java.util.Date;
import java.util.List;

public class Transaccion  {

    Date fecha;
    List<Transaccion> historico;
     public Double montoMovimiento;
    Cuenta cuenta;


    protected Transaccion() {

    }
    public Transaccion(TransaccionBuilder transaccionBuilder) {
        this.montoMovimiento = transaccionBuilder.montoMovimiento;
        this.cuenta = transaccionBuilder.cuenta;
        this.fecha = transaccionBuilder.fecha;
        this.historico = transaccionBuilder.historico;
    }
}


package co.com.validator;

import java.util.Date;

public class CuentaBuilder extends Cuenta {

    public static CuentaBuilder getBuilder(){


        return new CuentaBuilder();
    }

    public  CuentaBuilder ahorros(){

        this.tipo = "Ahorros";
        this.activa = true;

        return this;
    }

    public  CuentaBuilder ConNombre(String nombre){

        this.nombre = nombre;
        return this;

    }
    public  CuentaBuilder ConMonto(Double monto){

        this.monto = monto;
        return this;

    }
    public  CuentaBuilder ConTipo(String tipo){

        this.tipo = tipo;
        return this;

    }
    public  CuentaBuilder ConActiva(Boolean activa){

        this.activa = activa;
        return this;

    }
    public  CuentaBuilder ConFecha(Date registro){

        this.registro = registro;
        return this;
    }
    public Cuenta build(){
        return new Cuenta(this);
    }

}

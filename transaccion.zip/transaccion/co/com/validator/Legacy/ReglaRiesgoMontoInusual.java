package co.com.validator.Legacy;

import co.com.validator.Transaccion;

public final class ReglaRiesgoMontoInusual {
    public String aplicarRegla(Transaccion transaccion){
        if (transaccion.montoMovimiento > 1000.0){
            return "Regla violada monto inusual";
        }
        return "";

    }
}







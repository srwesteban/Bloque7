
package co.com.validator;

import java.util.Date;
import java.util.List;

public class TransaccionBuilder extends Transaccion {

    public static TransaccionBuilder getBuilder(){

        return new TransaccionBuilder();
    }

    public  TransaccionBuilder ConMonto(Double monto){

        this.montoMovimiento = monto;
        return this;

    }
    public  TransaccionBuilder ConCuenta(Cuenta cuenta){
        this.cuenta = cuenta;
        return this;

    }
    public  TransaccionBuilder ConHistorico(List historico){
        this.historico = historico;
        return this;

    }
    public  TransaccionBuilder ConFecha(Date fecha){
        this.fecha = new Date();
        return this;
    }
    public Transaccion build(){

        return new Transaccion(this);
    }

}
package co.com.validator;

import java.util.Date;

public class Cuenta {

    String tipo;
    Boolean activa;
    String nombre;
    Date registro;
    Double monto;

    protected Cuenta(){

    }

    public Cuenta(CuentaBuilder cuentaBuilder){
        this.monto = cuentaBuilder.monto;
        this.tipo = cuentaBuilder.tipo;
        this.nombre = cuentaBuilder.nombre;
        this.registro = cuentaBuilder.registro;
        this.activa = cuentaBuilder.activa;

    }

}
